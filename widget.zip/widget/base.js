document.addEventListener('DOMContentLoaded', function() {

    function checkReady(callback) {
      if (window.jQuery) {
        callback(jQuery);
      } else {
        window.setTimeout(function() {
          checkReady(callback);
        }, 20);
      }
    }
    
    var recognition;
    var isListening = false;
  
    function startSpeechRecognition() {
      if (!('webkitSpeechRecognition' in window)) {
        console.log('Speech recognition is not supported.');
        return;
      }
  
      recognition = new webkitSpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
  
      recognition.onstart = function() {
        // console.log('Speech recognition started.');
        isListening = true;
        micButton.classList.add('active');
      };
  
      recognition.onresult = function(event) {
        var interimTranscript = '';
        var finalTranscript = '';
        var textInput = document.getElementById('txtmsgid');
      
        for (var i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript !== '') {
          textInput.value = finalTranscript;
        } else {
          textInput.value = interimTranscript;
        }
      };
      
  
      recognition.onend = function() {
        // console.log('Speech recognition ended.');
        isListening = false;
        micButton.classList.remove('active');
      };
  
      recognition.onerror = function(event) {
        // console.error('Speech recognition error:', event.error);
        isListening = false;
        micButton.classList.remove('active');
      };
  
      recognition.start();
    }
  
    function stopSpeechRecognition() {
      if (recognition && isListening) {
        recognition.stop();
      }
    }
  
    function showChatBox() {
      var chatBox = document.getElementById('rsq_chat-box');
      chatBox.style.display = 'block';
      var rsqBox = document.getElementById('rsq_box');
      rsqBox.style.display = 'none';
    }
  
    function hideChatBox() {
      var chatBox = document.getElementById('rsq_chat-box');
      chatBox.style.display = 'none';
      var rsqBox = document.getElementById('rsq_box');
      rsqBox.style.display = 'block';
    }
  
    function refreshChat() {
      var responseContainer = document.getElementById('responseContainer');
      var containers = responseContainer.getElementsByClassName('container');
      for (var i = 0; i < containers.length; i++) {
        if (!containers[i].id.startsWith('initialMessageContainer')) {
          containers[i].remove();
        }
      }
    }
  
  
    function attachEventListeners() {
      var rsqBox = document.getElementById('rsq_box');
      rsqBox.addEventListener('click', showChatBox);
  
      var rsqMinimize = document.getElementById('rsq_minimize');
      rsqMinimize.addEventListener('click', hideChatBox);
  
      var rsqRefresh = document.getElementById('rsq_refresh');
      rsqRefresh.addEventListener('click', refreshChat);
  
      var textInput = document.getElementById('txtmsgid');
      textInput.addEventListener('keydown', function(event) {
        if (event.keyCode === 13) {
          sendMessage();
        }
      });
  
      textInput = document.getElementById('txtmsgid');
  
      var iconContainer = document.getElementById('iconText');
      iconContainer.addEventListener('click', sendMessage);
  
      micButton.addEventListener('mousedown', function() {
        micButton.classList.add('active');
        if (!isListening) {
          startSpeechRecognition();
        }
      });
      micButton.addEventListener('mouseup', function() {
        micButton.classList.remove('active');
        if (isListening) {
          stopSpeechRecognition();
        }
      });
      micButton.addEventListener('touchstart', function() {
        micButton.classList.add('active');
        if (!isListening) {
          startSpeechRecognition();
        }
      });
      
      micButton.addEventListener('touchend', function() {
        micButton.classList.remove('active');
        if (isListening) {
          stopSpeechRecognition();
        }
      });   
    }

    var suggestionQuestions = [
      'Hello',
      'How are you'
    ];

    function onSuggestionClick(suggestion) {
      var messageInput = document.getElementById('txtmsgid');
      messageInput.value = suggestion;
      sendMessage();
    }
  
    function createChatContainer() {
      var chatContainer = document.createElement('div');
      chatContainer.className = 'chat-container';
      chatContainer.id = 'my-chatbot-container';
  
      var row = document.createElement('div');
      row.className = 'row';
      chatContainer.appendChild(row);
  
      var chatBox = document.createElement('div');
      chatBox.id = 'rsq_chat-box';
      chatBox.innerHTML = '<h2 class="rsq-icon">Chakra</h2>';
      chatBox.style.display = 'none';
      row.appendChild(chatBox);
  
      var chatIcon = createChatIcon();
      row.appendChild(chatIcon);
  
      var minimizeButton = document.createElement('span');
      minimizeButton.id = 'rsq_minimize';
      minimizeButton.innerHTML = '<i class="fa fa-minus"></i>';
      chatBox.appendChild(minimizeButton);
  
      var refreshButton = document.createElement('span');
      refreshButton.id = 'rsq_refresh';
      refreshButton.innerHTML = '<i class="fas fa-sync-alt"></i>';
      chatBox.appendChild(refreshButton);
  
      var headerText = document.createElement('h4');
      headerText.className = 'rsq_header-text';
      chatBox.appendChild(headerText);
  
      var demoText = document.createElement('p');
      demoText.id = 'rsq_demo';
      chatBox.appendChild(demoText);
  
      var inputsContainer = document.createElement('div');
      inputsContainer.id = 'rsq_inputs';
      chatBox.appendChild(inputsContainer);
  
      var responseContainer = document.createElement('div');
      responseContainer.id = 'responseContainer';
      responseContainer.className = 'responseContainer';
      inputsContainer.appendChild(responseContainer);
  
      var initialMessageContainer = document.createElement('div');
      initialMessageContainer.id = 'initialMessageContainer';
      initialMessageContainer.className = 'container';
      responseContainer.appendChild(initialMessageContainer);
  
      var initialMessage = document.createElement('div');
      initialMessage.className = 'response-container';
      initialMessage.innerHTML =
        '<img src="bot_logo.png" class="msg-bot-img"/><div class="msg-bot">Hey, How can I help you with Bridgeport University?</div>';
      initialMessageContainer.appendChild(initialMessage);

      var suggestionBox = document.createElement('div');
      suggestionBox.id = 'suggestionBox';
      suggestionBox.className = 'suggestion-box';
      chatBox.appendChild(suggestionBox);

      suggestionQuestions.forEach(function (question) {
        var suggestionItem = document.createElement('div');
        suggestionItem.className = 'suggestion-item';
        suggestionItem.textContent = question;
        suggestionItem.addEventListener('click', function () {
          onSuggestionClick(question);
        });
        suggestionBox.appendChild(suggestionItem);
      });

      var formContainer = document.createElement('div');
      formContainer.id = 'bolForm';
      formContainer.className = 'msg-bottom';
      chatBox.appendChild(formContainer);
  
      var inputContainer = document.createElement('div');
      inputContainer.className = 'chat-input-container';
      formContainer.appendChild(inputContainer);
  
      var textInput = document.createElement('input');
      textInput.type = 'text';
      textInput.className = 'chat-input';
      textInput.name = 'text_msg';
      textInput.id = 'txtmsgid';
      textInput.placeholder = 'Please enter your text here....';
      textInput.autocomplete = 'off';
      textInput.autofocus = true;
      textInput.addEventListener('keydown', function(event) {
        if (event.keyCode === 13) {
          sendMessage();
        }
      });
      inputContainer.appendChild(textInput);
  
      var micButton = document.createElement('button');
      micButton.id = 'micButton';
      micButton.className='mic-button'
      micButton.innerHTML = '<i class="fas fa-microphone"></i>';
      inputContainer.appendChild(micButton);
  
      var iconContainer = document.createElement('span');
      iconContainer.className = 'icon-container';
      iconContainer.id = 'iconText';
      inputContainer.appendChild(iconContainer);
  
      var sendIcon = document.createElement('i');
      sendIcon.className = 'fas fa-paper-plane';
      iconContainer.appendChild(sendIcon);
  
      var bottomMsg = document.createElement('div');
      bottomMsg.className = 'bottom-msg';
      bottomMsg.innerHTML =
        'Powered by <span><a href="https://coretek.io/" target="_blank">Coretek.io</a></span>';
      formContainer.appendChild(bottomMsg);
  
      row.appendChild(chatBox);
      appendStylesheet('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css');
      appendStylesheet('style.css');
      // appendStylesheet('https://chatbubble.s3.amazonaws.com/styles.9d8de2bd938fe28ede57.css')
      document.body.appendChild(chatContainer);
    }
  
    function createChatIcon() {
      var chatIcon = document.createElement('div');
      chatIcon.id = 'rsq_box';
      chatIcon.innerHTML =
        '<img src="bot_logo.png" alt="chat-icon" />';
      return chatIcon;
    }
  
    function appendStylesheet(url) {
      var stylesLink = document.createElement('link');
      stylesLink.rel = 'stylesheet';
      stylesLink.href = url;
      document.head.appendChild(stylesLink);
    }
  
    function appendScript(url) {
      var script = document.createElement('script');
      script.src = url;
      document.head.appendChild(script);
    }
  
    function toggleChatBox() {
      var chatBox = document.getElementById('rsq_chat-box');
      chatBox.style.display = chatBox.style.display === 'none' ? 'block' : 'none';
    }
  
    function sendMessage() {
      var messageInput = document.getElementById('txtmsgid');
      var message = messageInput.value.trim();
  
      if (message === '') {
        return false;
      }
  
      var newContainer = createResponseContainer();
      var userMessage = createUserMessage(message);
      newContainer.appendChild(userMessage);
      messageInput.value = '';
  
      scrollToBottom();
    
      var url = '';
      var data = {
        session_id:'1',
        query: message
      };
  
      showLoadingIndicator(newContainer);
      scrollToBottom();
  
  
      makeAjaxRequest(url, data)
        .then(function(response) {
          // console.log(response);
          var answer = response.Answer;
          hideLoadingIndicator(newContainer);
          showTypingIndicator(newContainer);
          addBotMessage(newContainer, answer);
          scrollToBottom();
        })
        .catch(function(error) {
          // console.log('AJAX Error:', error.Answer);
          hideLoadingIndicator(newContainer);
          showTypingIndicator(newContainer);
          addBotMessage(newContainer, 'An error occurred. Please try again.')
          // showError(newContainer);
          scrollToBottom();
        });
    }
  
    function createResponseContainer() {
      var newContainer = document.createElement('div');
      newContainer.className = 'container';
      document.getElementById('responseContainer').appendChild(newContainer);
      return newContainer;
    }
  
    function createUserMessage(message) {
      var userMessage = document.createElement('div');
      userMessage.className = 'user-chat-container';
      userMessage.innerHTML = '<div class="msg-user">' + message + '</div><img src="user_logo.png" class="msg-user-img"/>';
      return userMessage;
    }
  
    function scrollToBottom() {
      var responseContainer = document.getElementById('responseContainer');
      responseContainer.scrollTop = responseContainer.scrollHeight;
    }
  
    function showLoadingIndicator(container) {
      var loaderContainer = document.createElement('div');
      loaderContainer.className = 'response-container';
      loaderContainer.innerHTML = '<img src="bot_logo.png" class="msg-bot-img"/><div class="loader"></div>';
      container.appendChild(loaderContainer);
    }
  
    function hideLoadingIndicator(container) {
      var loaderContainer = container.querySelector('.response-container');
      if (loaderContainer) {
        loaderContainer.remove();
      }
    }
  
    function showTypingIndicator(container) {
      var typingIndicator = document.createElement('div');
      typingIndicator.className = 'response-container typing-indicator';
      typingIndicator.innerHTML = '<span></span><span></span><span></span>';
      container.appendChild(typingIndicator);
    }
  
    function addBotMessage(container, message) {
      var typingIndicator = container.querySelector('.typing-indicator');
      if (typingIndicator) {
        typingIndicator.remove();
      }
  
      var botMessageContainer = document.createElement('div');
      botMessageContainer.className = 'response-container';
  
      var botMessage = document.createElement('div');
      botMessage.className = 'msg-bot';
  
      var botImage = document.createElement('img');
      botImage.className = 'msg-bot-img';
      botImage.src = 'bot_logo.png';
  
      botMessageContainer.appendChild(botImage);
      botMessageContainer.appendChild(botMessage);
      container.appendChild(botMessageContainer);
  
      var addCharacter = function(i) {
        if (i < message.length) {
          botMessage.textContent += message.charAt(i);
          scrollToBottom();
          setTimeout(function() {
            addCharacter(i + 1);
          }, Math.floor(Math.random() * 50));
        } else {
          scrollToBottom();
        }
      };
  
      addCharacter(0);
    }
  
    function showError(container) {
      var errorContainer = document.createElement('div');
      errorContainer.className = 'response-container error-msg';
      errorContainer.textContent = 'An error occurred. Please try again.';
  
      container.appendChild(errorContainer);
    }
  
    function makeAjaxRequest(url, data) {
      return new Promise(function(resolve, reject) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Content-Type', 'application/json');
  
        xhr.onload = function() {
          if (xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            // console.log(response)
            resolve(response);
          } else {
            reject(xhr.statusText);
          }
        };
  
        xhr.onerror = function() {
          reject('Network Error');
        };
  
        xhr.send(JSON.stringify(data));
      });
    }
  
    createChatContainer();
    attachEventListeners();
  
  })